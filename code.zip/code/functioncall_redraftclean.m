% function call example for use in same folder as the function file
% ITSNTSrich.m, as set up this will produce a copy of figure 6, column C
% i.e. fluctuations, bottlenecks, entrenchment combined. this script does a
% cross-referenced sensitvity analysis to producer cost and length of
% off (and on) intervals during the fluctuations. Other possible
% sensitivity analyses are included in this file but currently commented
% out
clear 
%close all
reps=50;
%incsbase=25;
% increments for off interval
incsoff=50;
%incsoff=1;
%increments for subdivision of other parameters
incsparam=50;
%incsparam=1;


costmin=0.0;
costmax=1.0;
%costmax=0.2;

offmin=0;
offmax=220;



%mutin=0.05;
%mutmax=1;
mutmax=0.05;
mutmin=0;

prodlossmin=0;
prodlossmax=1;

symmin=0;
symmax=1;

substanceinputmin=1;
substanceinputmax=100;

Rnet0min=50;
Rnet0max=200;

%total runs counter
counter=0;

entrenchmentmin=0;
entrenchmentmax=1;

foundermin=1;
foundermax=200;

CRmeancontour=zeros(incsparam,incsoff);
Corrstore2contour=zeros(incsparam,incsoff);
RFPstorecontour=zeros(incsparam,incsoff);
Popstorecontour=zeros(incsparam,incsoff);
costcontour=zeros(incsparam,incsoff);
offcontour=zeros(incsparam,incsoff);

% costinterval=[costmin:(costmax-costmin)/incsparam:(costmin+((incsparam-1)/incsparam)*(costmax-costmin))];
% offinterval=[offmin:(offmax-offmin)/incsoff:(offmin+((incsoff-1)/incsoff)*(offmax-offmin))];

%[X,Y]=meshgrid(costinterval,offinterval);


% parameter combinations counter
counterparams=0;
counterparams2=0;
%for f=1:incsparam
for f=1:1
     % only vary on this index if you want maximum tolerable shut off length runs, 
     % or other 3 parameter analyses
     %mutin=mutmin+((f-1)/incsparam)*(mutmax-mutmin);
     mutin=0.01;
     
     %syminput=symmin+((f-1)/incsparam)*(symmax-symmin);
     syminput=1;
     substanceinput=10;
     %substanceinput=substanceinputmin+((f-1)/incsparam)*(substanceinputmax-substanceinputmin);
     %prodlossin=prodlossmin+((f-1)/incsparam)*(prodlossmax-prodlossmin);
     prodlossin=0.4;
     %entrenchin=entrenchmentmin+((f-1)/incsparam)*(entrenchmentmax-entrenchmentmin);
        for k=1:incsparam+1
            costin=costmin+((k-1)/incsparam)*(costmax-costmin);
            %costin=0.01;
            Rnet0in=100;
            %Rnet0in=Rnet0min+((j-1)/incs)*(Rnet0max-Rnet0min);

            for i=1:incsoff+1
            %for i=1:incsparam+1
                %entrenchin=entrenchmentmin+((i-1)/incsparam)*(entrenchmentmax-entrenchmentmin);
                entrenchin=0.5;
                %coststoreshort(i)=costmin+((i-1)/incs)*(costmax-costmin);
                offin=offmin+((i-1)/incsoff)*(offmax-offmin);
                %mutin=mutmin+((i-1)/incsparam)*(mutmax-mutmin);
                %offin=100;
                
                %entrenchin=0.5;
                %founderin=round(foundermin+((i-1)/incsparam)*(foundermax-foundermin));
                founderin=1;


                loopfixtally=0;
                for j=1:reps
%                     if j==1
%                         disp('shut-off interval= '+string(offin));
%                         disp('cost= '+string(costin));
%                     end;
                    
                    counter=counter+1;
                    if j<0 % change to >0 to plot individual runs
                        graphtoggle=1;
                        %graphtoggle=0;
                    else
                        graphtoggle=0;
                    end;
                    %call model for this run
                    [CR,Prod,Pop,CR1,CR2,S1,S2,RFP1,RFP2,CRasym,Popasym,Assimmean]=ITSNTSrich(offin,costin,...
                        mutin,prodlossin,syminput,substanceinput,...
                        Rnet0in,entrenchin,founderin,graphtoggle);
                    % model output
                    CRthis(j)=CR;
                    Prodthis(j)=Prod;
                    RFP1this(j)=RFP1;
                    RFP2this(j)=RFP2;
                    Popthis(j)=Pop;
                    S1this(j)=S1;
                    S2this(j)=S2;
                    CR1this(j)=CR1;
                    CR2this(j)=CR2;
                    CRasymthis(j)=CRasym;
                    Popasymthis(j)=Popasym;
                    Assimthis(j)=Assimmean;
                    
                    CRasymstore(counter)=CRasym;
                    Popasymstore(counter)=Popasym;
                    popstore(counter)=Pop;
                    S1store(counter)=S1;
                    S2store(counter)=S2;
                    prodstore(counter)=Prod;
                    RFP1store(counter)=RFP1;
                    RFP2store(counter)=RFP2;
                    CRstore(counter)=CR;
                    CR1store(counter)=CR1;
                    CR2store(counter)=CR2;
                    offstorelong(counter)=offin;
                    coststorelong(counter)=costin;
                    mutstorelong(counter)=mutin;
                    prodlossstorelong(counter)=prodlossin;
                    symstorelong(counter)=syminput;
                    substancestorelong(counter)=substanceinput;
                    entrenchstorelong(counter)=entrenchin;
                    founderstorelong(counter)=founderin;
                    %cycle "lock in" criteria
                    if prodstore(counter)==1 && popstore(counter)>0
                        loopfixtally=loopfixtally+1;
                    end;
                    %2 parameter analysis
                    disp('run '+string(counter)+' of '+string(reps*(incsoff+1)*(incsparam+1))+' complete');
                    %3 parameter analysis
                    %disp('run '+string(counter)+' of '+string(reps*((incsparam+1)^2))+' complete');

                end; % end of j index corresponds to completion of all reps for this parameter combination
                
                % reps done for this off/param combination
                %counterparams=counterparams+1;
                % STATS ACROSS REPLICATES FOR THIS OFF-INTERVAL
                % trusting this https://uk.mathworks.com/help/matlab/ref/cov.html
                % https://uk.mathworks.com/help/matlab/ref/corrcoef.html
                % correlations across replicates, vector "X_this" is "reps"
                % long and contains value of the relevant quantity for each
                % run with this parameter choice
                % CORR(CYCLING RATIO, PRODUCER FREQ)
                corrmatrix=corrcoef(CRthis,Prodthis,'rows','complete');
                corrmatrix(isnan(corrmatrix))=0;
                corrstore(i)=0.5*(corrmatrix(2,1)+corrmatrix(1,2));
                %CORRELATION BETWEEN SPECIES AVERAGED POP SIZE
                %AND SUBSTANCE-AVERAGED CYCLING RATIO  
                corrmatrix2=corrcoef(CRthis,Popthis,'rows','complete');
                corrmatrix2(isnan(corrmatrix2))=0;
                %disp(corrmatrix);
                corrstore2(i)=0.5*(corrmatrix2(2,1)+corrmatrix2(1,2));

                corrmatrix3=corrcoef(Popthis,Prodthis,'rows','complete');
                corrmatrix3(isnan(corrmatrix3))=0;
                corrstore3(i)=0.5*(corrmatrix3(2,1)+corrmatrix3(1,2));
                
                %CORR(CYCLING RATIO S1, S2)
                corrmatrixCR=corrcoef(CR1this,CR2this);
                corrmatrixCR(isnan(corrmatrixCR))=0;
                corrstoreCR(i)=0.5*(corrmatrixCR(2,1)+corrmatrixCR(1,2));

                Popvarstore(i)=var(Popthis);
                CovCRPop=cov(CRthis,Popthis);
                CovarCRPopstore(i)=0.5*(CovCRPop(2,1)+CovCRPop(1,2));

                CovProdPop=cov(Prodthis,Popthis);
                CovarProdPopstore(i)=0.5*(CovProdPop(2,1)+CovProdPop(1,2));
                
                %calculate average values for this set of replicates
                Popreplicatemean(i)=sum(Popthis)/reps;
                S1replicatemean(i)=sum(S1this)/reps;
                S2replicatemean(i)=sum(S2this)/reps;
                CRreplicatemean(i)=sum(CRthis)/reps;
                CR1replicatemean(i)=sum(CR1this)/reps;
                CR2replicatemean(i)=sum(CR2this)/reps;
                RFP1replicatemean(i)=sum(RFP1this)/reps;
                RFP2replicatemean(i)=sum(RFP2this)/reps;
                CRasymreplicatemean(i)=sum(CRasymthis)/reps;
                Popasymreplicatemean(i)=sum(Popasymthis)/reps;
                Assimreplicatemean(i)=sum(Assimthis)/reps;
                RFPreplicatemean(i)=sum(Prodthis)/reps;
                
                % store for graphs
                offstoreshort(i)=offin;
                coststoreshort(i)=costin;
                mutstoreshort(i)=mutin;
                prodlossstoreshort(i)=prodlossin;
                symstoreshort(i)=syminput;
                substancestoreshort(i)=substanceinput;
                Rnet0storeshort(i)=Rnet0in;
                entrenchstoreshort(i)=entrenchin;
                founderstoreshort(i)=founderin;
                fixedproportion(i)=loopfixtally/reps;

                counterparams=counterparams+1;
                coststoremean2(counterparams)=costin;
                offstoremean2(counterparams)=offin;
                Popstoremean2(counterparams)=Popreplicatemean(i);
                S1storemean(counterparams)=S1replicatemean(i);
                S2storemean(counterparams)=S2replicatemean(i);
                CRstoremean2(counterparams)=CRreplicatemean(i);
                CR1storemean(counterparams)=CR1replicatemean(i);
                CR2storemean(counterparams)=CR2replicatemean(i);
                RFPstoremean2(counterparams)=RFPreplicatemean(i);
                RFP1storemean(counterparams)=RFP1replicatemean(i);
                RFP2storemean(counterparams)=RFP2replicatemean(i);
                Corrstoremean2(counterparams)=corrstore(i);
                Corrstore2mean2(counterparams)=corrstore2(i);
                mutstoremean2(counterparams)=mutin;
                Popvarstoremean2(counterparams)=Popvarstore(i);
                founderstoremean2(counterparams)=founderin;
                entrenchstoremean2(counterparams)=entrenchin;
                CorrstoreCRmean(counterparams)=corrstoreCR(i);
                CRasymstore(counterparams)=CRasymreplicatemean(i);
                Popasymstore(counterparams)=Popasymreplicatemean(i);
                Assimstore(counterparams)=Assimreplicatemean(i);

                
                %set contour objects for graphs (index k is the first
                %parameter index, usually cost, index i the second, usually
                %the off interval
                CRmeancontour(k,i)=CRstoremean2(counterparams);
                %cycling ratio and producer freq correlation:
                Corrstore2contour(k,i)=Corrstoremean2(counterparams);
                % correlation cycling ratio of each substance:
                CorrstoreCRcontour(k,i)=CorrstoreCRmean(counterparams);
                RFPstorecontour(k,i)=RFPstoremean2(counterparams);
                Popstorecontour(k,i)=Popstoremean2(counterparams);
                S1storecontour(k,i)=S1storemean(counterparams);
                S2storecontour(k,i)=S2storemean(counterparams);
                CR1storecontour(k,i)=CR1storemean(counterparams);
                CR2storecontour(k,i)=CR2storemean(counterparams);
                RFP1storecontour(k,i)=RFP1storemean(counterparams);
                RFP2storecontour(k,i)=RFP2storemean(counterparams);
                CRasymstorecontour(k,i)=CRasymstore(counterparams);
                Popasymstorecontour(k,i)=Popasymstore(counterparams);
                Assimstorecontour(k,i)=Assimstore(counterparams);
                costcontour(k,i)=costin;
                offcontour(k,i)=offin;
                fixedproportioncontour(k,i)=100*fixedproportion(i);
                entrenchfraccontour(k,i)=entrenchin;
                bottlenecksizecontour(k,i)=founderin;
                mutcontour(k,i)=mutin;
            end;

            % max off interval calculations
            % offinterval sensivity analysis now complete for this parameter
            % choice
            % find maximum index in pop size vector that is non-zero
            maxoffindex=max(find(Popreplicatemean));
            if maxoffindex>0
                % get the corresponding shut-off interval length
                maxoffinterval(k)=offstoreshort(maxoffindex);
            else
                maxoffinterval(k)=0;
            end;
            
            % will be a single set of max-off values unless you are also
            % incrementing over a third parameter via index f above
            maxoffcontour(k,f)=maxoffinterval(k);
            maxoffcostcontour(k,f)=costin;
            maxoffmutcontour(k,f)=mutin;
            maxoffsymcontour(k,f)=syminput;
            maxoffR0contour(k,f)=substanceinput;
            maxoffprodlosscontour(k,f)=prodlossin;
        end;
end;


% GRAPHS

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIGURE 12 SUPPLEMENT
% figure
% subplot(2,3,1);
% scatter3(coststorelong,offstorelong,CRstore,[],CRstore,'filled')
% xlabel('producer cost')
% xlim([costmin costmax]);
% ylabel('shut-off length')
% ylim([offmin offmax]);
% zlabel('cycling ratio')
% zlim([0 max(CRstore,[],'all')]);
% caxis([0 9]);
% colormap('jet');
% colorbar;
% title({'SINGLE SHUT-OFF','1A'});
% subplot(2,3,4);
% scatter3(coststorelong,offstorelong,prodstore,[],prodstore,'filled')
% xlabel('producer cost')
% xlim([costmin costmax]);
% ylabel('shut-off length')
% ylim([offmin offmax]);
% zlabel('relative producer frequency')
% zlim([0 1]);
% caxis([0 1]);
% colormap('jet');
% colorbar;
% title('1B');
% 
% % % 
% subplot(2,3,2);
% scatter3(coststorelong,offstorelong,CRstore,[],CRstore,'filled')
% xlabel('producer cost')
% xlim([costmin costmax]);
% ylabel('shut-off length')
% ylim([offmin offmax]);
% zlabel('cycling ratio')
% zlim([0 max(CRstore,[],'all')]);
% colormap('jet');
% colorbar;
% caxis([0 9]);
% title({'FLUCTUATIONS ONLY','2A'});
% subplot(2,3,5);
% scatter3(coststorelong,offstorelong,prodstore,[],prodstore,'filled')
% xlabel('producer cost')
% xlim([costmin costmax]);
% ylabel('shut-off length')
% ylim([offmin offmax]);
% zlabel('relative producer frequency')
% zlim([0 1]);
% caxis([0 1]);
% colormap('jet');
% colorbar;
% title('2B');
% % 
% subplot(2,3,3);
% scatter3(coststorelong,offstorelong,CRstore,[],CRstore,'filled')
% xlabel('producer cost')
% xlim([costmin costmax]);
% ylabel('shut-off length')
% ylim([offmin offmax]);
% zlabel('cycling ratio')
% zlim([0 max(CRstore,[],'all')]);
% colormap('jet');
% caxis([0 9]);
% colorbar;
% title({'FLUCTUATIONS, DRIFT AND ENTRENCHMENT','3A'});
% subplot(2,3,6);
% scatter3(coststorelong,offstorelong,prodstore,[],prodstore,'filled')
% xlabel('producer cost')
% xlim([costmin costmax]);
% ylabel('shut-off length')
% ylim([offmin offmax]);
% zlabel('relative producer frequency')
% caxis([0 1]);
% zlim([0 1]);
% colormap('jet');
% colorbar;
% title('3B');
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIGURES 4 AND 9
% figure
% subplot(2,2,1)
% contourf(costcontour,offcontour,RFPstorecontour)
% colormap(jet);
% colorbar;
% caxis([0 1]);
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylim([offmin offmax]);
% zlabel('relative frequency');
% zlim([0 1]);
% ylabel('length of shut-off interval');
% title('1A. Producer relative frequency (two species average)');
% subplot(2,2,2);
% contourf(costcontour,offcontour,Popstorecontour);
% %colormap(cool);
% colorbar;
% caxis([0 max(Popstorecontour,[],'all')]);
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylim([offmin offmax]);
% ylabel('length of shut-off interval');
% title('1B. Total population (two species average)');
% subplot(2,2,3);
% contourf(costcontour,offcontour,CRmeancontour);
% %colormap(summer);
% colorbar;
% caxis([0 max(CRmeancontour,[],'all')]);
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylim([offmin offmax]);
% ylabel('length of shut-off interval');
% zlabel('value');
% %zlim([-1 1]);
% title('2A. Cycling ratio (two substance average)')
% subplot(2,2,4)
% contourf(costcontour,offcontour,Assimstorecontour);
% colorbar;
% caxis([0 max(Assimstorecontour, [], 'all')]);
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylim([offmin offmax]);
% ylabel('length of shut-off interval');
% title('2B. Total assimilation rate (two species average)');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     

% figure
% subplot(2,3,1)
% contourf(costcontour,entrenchfraccontour,fixedproportioncontour);
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('entrenchment fraction');
% ylim([entrenchmentmin entrenchmentmax]);
% %caxis([0 1]);
% %caxis([0 max(fixedproportioncontour,[],'all')]);
% caxis([0 100]);
% title('1A. % runs with lock-in');
% 
% subplot(2,3,2)
% contourf(costcontour,entrenchfraccontour,CRmeancontour);
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('entrenchment fraction');
% ylim([entrenchmentmin entrenchmentmax]);
% caxis([0 max(CRmeancontour,[],'all')]);
% title('2A. Cycling ratio (mean)');
% 
% subplot(2,3,3)
% contourf(costcontour,entrenchfraccontour,Popstorecontour);
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('entrenchment fraction');
% ylim([entrenchmentmin entrenchmentmax]);
% caxis([0 max(Popstorecontour,[],'all')]);
% title('3A. Population size');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% FIGURE 7
% figure
% subplot(2,2,1)
% contourf(costcontour,entrenchfraccontour,fixedproportioncontour);
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('entrenchment fraction');
% ylim([entrenchmentmin entrenchmentmax]);
% %caxis([0 1]);
% %caxis([0 max(fixedproportioncontour,[],'all')]);
% caxis([0 100]);
% title('1A. entrenchment fraction');
% 
% subplot(2,2,2)
% contourf(costcontour,bottlenecksizecontour,fixedproportioncontour);
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('bottleneck size');
% ylim([foundermin foundermax]);
% %caxis([0 max(fixedproportioncontour,[],'all')]);
% caxis([0 100]);
% % title('2A. bottleneck size');
% 
% subplot(2,2,3)
% contourf(costcontour,offcontour,fixedproportioncontour);
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('shut-off length');
% ylim([offmin offmax]);
% caxis([0 100]);
% title('1B. length of shut-off interval');
% % 
% subplot(2,2,4)
% contourf(costcontour,mutcontour,fixedproportioncontour)
% colorbar
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('mutation rate');
% ylim([mutmin mutmax]);
% caxis([0 100]);
% title('2B. mutation rate');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 

%%%%%%%%%%%%%%%%%%%
%%%% FIGURE 5
% figure
% subplot(2,2,1);
% contourf(maxoffcostcontour,maxoffmutcontour,maxoffcontour)
% colorbar;
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('mutation rate');
% ylim([mutmin mutmax]);
% %clabel('maximum tolerable shut-off interval');
% caxis([offmin offmax]);
% % 
% subplot(2,2,2);
% contourf(maxoffcostcontour,maxoffsymcontour,maxoffcontour)
% colorbar;
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('symmetry');
% ylim([symmin symmax]);
% %clabel('maximum tolerable shut-off interval');
% caxis([offmin offmax]);
% 
% subplot(2,2,3);
% contourf(maxoffcostcontour,maxoffR0contour,maxoffcontour);
% colorbar;
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('Abiotic residence time');
% % %clabel('maximum tolerable shut-off interval');
% caxis([offmin offmax]);
% 
% subplot(2,2,4);
% contourf(maxoffcostcontour,maxoffprodlosscontour,maxoffcontour)
% colorbar;
% colormap('jet');
% xlabel('producer cost');
% xlim([costmin costmax]);
% ylabel('production loss fraction');
% %clabel('maximum tolerable shut-off interval');
% caxis([offmin offmax]);
% % 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FIGURE 8
figure
subplot(3,3,1)
contourf(costcontour,offcontour,CorrstoreCRcontour)
colorbar;
colormap('jet');
xlim([costmin costmax]);
xlabel('producer cost');
ylim([offmin offmax]);
caxis([-1 1]);
ylabel('shut-off length');
title('1A. single shut-off, CORR(CR(R_1),CR(R_2))');

subplot(3,3,4)
contourf(costcontour,offcontour,Corrstore2contour)
colorbar;
colormap('jet');
xlim([costmin costmax]);
xlabel('producer cost');
caxis([-1 1]);
ylim([offmin offmax]);
ylabel('shut-off length');
title('1B. single shut-off, CORR(CR,RFP)');

subplot(3,3,7)
contourf(costcontour,offcontour,RFPstorecontour)
colorbar;
colormap('jet');
xlim([costmin costmax]);
xlabel('producer cost');
caxis([0 1]);
ylim([offmin offmax]);
ylabel('shut-off length');
title('1C. single shut-off, RFP)');
% % 
% subplot(3,3,2)
% contourf(costcontour,offcontour,CorrstoreCRcontour)
% colorbar;
% colormap('jet');
% xlim([costmin costmax]);
% xlabel('producer cost');
% ylim([offmin offmax]);
% caxis([-1 1]);
% ylabel('shut-off length');
% title('2A. fluctuations, CORR(CR(R_1),CR(R_2))');
% 
% subplot(3,3,5)
% contourf(costcontour,offcontour,Corrstore2contour)
% colorbar;
% colormap('jet');
% xlim([costmin costmax]);
% xlabel('producer cost');
% ylim([offmin offmax]);
% caxis([-1 1]);
% ylabel('shut-off length');
% title('2B. fluctuations, CORR(CR,RFP)');
% 
% subplot(3,3,8)
% contourf(costcontour,offcontour,RFPstorecontour)
% colorbar;
% colormap('jet');
% caxis([0 1]);
% xlim([costmin costmax]);
% xlabel('producer cost');
% ylim([offmin offmax]);
% ylabel('shut-off length');
% title('2C. fluctuations, RFP)');
% 
% 
% figure
% subplot(3,3,3)
% contourf(costcontour,offcontour,CorrstoreCRcontour)
% colorbar;
% colormap('jet');
% xlim([costmin costmax]);
% xlabel('producer cost');
% ylim([offmin offmax]);
% caxis([-1 1]);
% ylabel('shut-off length');
% title('3A. fluctuations, drift and entrenchment, CORR(CR(R_1),CR(R_2))');
% 
% subplot(3,3,6)
% contourf(costcontour,offcontour,Corrstore2contour)
% colorbar;
% colormap('jet');
% xlim([costmin costmax]);
% xlabel('producer cost');
% ylim([offmin offmax]);
% caxis([-1 1]);
% ylabel('shut-off length');
% title('3B. fluctuations, drift and entrenchment, CORR(CR,RFP)');
% 
% subplot(3,3,9)
% contourf(costcontour,offcontour,RFPstorecontour)
% colorbar;
% colormap('jet');
% xlim([costmin costmax]);
% xlabel('producer cost');
% ylim([offmin offmax]);
% caxis([0 1]);
% ylabel('shut-off length');
% title('3C. fluctuations, drift and entrenchment, RFP)');
% % 
% 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % 
% % 
% 
% 
% 