function [CRmean,Prodmean,Popmean,CRR1final,CRR2final,S1final,S2final,RFP1final,RFP2final,CRasym,Popasym,Assimmean]=ITSNTSrich(offlengthin,costin,mutin,prodlossin...
    ,fsymmetryin,substancein,Rnetbasein,entrenchin,founderin,graphtoggle)


% code for "The evolution of biogeochemical recycling by persistence-based
% selection" written by Richard Boyle whilst employed as a postdoc in the
% Earth system modelling group, global systems institute,
% university of Exeter. Questions/comments to richboyleacademic@gmail.com 
% https://www.exeter.ac.uk/gsi/
% https://scholar.google.com/citations?user=xQL9Rx8AAAAJ&hl=en
% 
 %clear
 %close all

% seed random number generator with the clock
rng('shuffle');
%PARAMETERS
%total simulation length, generations
%gens=2000;
gens=2000;


% timestep (generations)
dt=1;
% increments
steps=gens/dt;

% GROWTH RATES
% universal baseline growth rate (new individuals produced per parent
% individual per generation), average growth rate=1 corresponds to steady
% state population
G0=5;
%G0=10;
% Maximum rate of environmental substance assimilation, per individual per
% generation, puts a cap on growth rate across genotypes
Rassimbase=3;
R1assimmax=Rassimbase;
R2assimmax=Rassimbase;
%efficiency with which assimilation of growth-limiting environmental 
%substance produces new individuals
fconv=0.5;
%fconv=0.01;
%efficiency with which producers convert the substance they assimilate to
%the other substance
fprodloss=prodlossin;
%fprodloss=0.4;
fconvprod=(1-fconv)*(1-fprodloss);
%symmetry breaker
%fsymmetry=1;
fsymmetry=fsymmetryin;
%fconvprod=0.5;
% factor by which producer reproductive growth rate is offset compared to
% cheater, assumed inversely related
%cost=0.1;
%cost=0.01;
cost=costin;
% bioavailable environmental substance level below which facultative
% becomes a cheater, above which it is a producer
Rmin=1;
% species and genotype specific maximum growth rates
% species 1, cheater, net
S1GCmax=G0*R1assimmax;
% species 1, cheater, per unit substance assimilated
S1GCPR=S1GCmax/R1assimmax;
% species 2, cheater, net
S2GCmax=G0*R2assimmax;
% species 2, cheater per unit substance assimilated
S2GCPR=S2GCmax/R2assimmax;
% species 1, producer, net
S1GPmax=G0*(1-cost)*R1assimmax;
% species 1, producer, per unit substance assimilated
S1GPPR=S1GPmax/R1assimmax;
% species 2, producer,net

S2GPmax=G0*(1-cost)*R2assimmax;
% species 2, producer, per unit substance assimilated
S2GPPR=S2GPmax/R2assimmax;

% SPECIES AND GENOTYPE FREQUENCIES
%randomize initial frequencies by setting this to 1
%randomizationtoggle=1;
randomizationtoggle=0;
if randomizationtoggle==1
    x=randi([1,3],1);
    if x==1
        Prodbase=10;
        Cheatbase=0;
        Facbase=0;
    else
        if x==2
            Prodbase=0;
            Cheatbase=10;
            Facbase=0;
        else
            Prodbase=10;
            Cheatbase=10;
            Facbase=10;
        end;
    end;
else
    %default initial frequencies, assume equal across species
    % change starting frequencies here with toggle set to zero
    Prodbase=10;
    Cheatbase=10;
    Facbase=10;
end;
% initial number of producers, time=0, species 1
S1P0=Prodbase;
% initial number of producers, time=0, species 2
S2P0=Prodbase;
% initial number of cheaters, species 1
S1C0=Cheatbase;
% initial number of cheaters, species 2
S2C0=Cheatbase;
%initial facultative, species 1
S1F0=Facbase;
%initial facultative, species 2
S2F0=Facbase;

%ENVIRONMENTAL SUBSTANCES 
%baseline quantity of environmental substance per generation
%substancefactor=10;
%substancefactor=100;
substancefactor=substancein;
%Rnetbase=100;
Rnetbase=Rnetbasein;
% starting total number of units of environmental substance R1
R1net0=Rnetbase;
% starting total number of units of environmental substance R2
R2net0=Rnetbase;
% input, units of environmental substance per tgeo/tbio
R1influx=substancefactor;
% input, units of environmental substance per tgeo/tbio
R2influx=substancefactor;
%biotic production of R1 by species 2
BPR10=S2P0/S2GPmax;
%biotic production of R2 by species 1
BPR20=S1P0/S1GPmax;
%carrying capacity
K=10000;
% sensitivity of time derivative to carrying capacity 
thinning=1;

%MUTATION AND RANDOM DEATH
% inter-genotype mutation probability
%mutprob0=0.00001;
mutprob0=mutin;
%mutprob0=0.01;
%mutprob0=0.0;
% death by random factors "drift" etc, default and high
deathprob0=0.1;
%deathprobhigh=0.4;
% At default random death rate does nothing, comment in above to turn on
deathprobhigh=deathprob0;

% scaling factor for abiotic flux relative to biotic
% dynamics
dtgeodtbio0=1;

%PREALLOCATE VECTORS
% time, generations
timeplot=zeros(1,steps);
%producers species 1
S1Pout=zeros(1,steps);
%producers species 2
S2Pout=zeros(1,steps);
% cheaters species 1
S1Cout=zeros(1,steps);
% cheaters species 2
S2Cout=zeros(1,steps);
% facultative species 1
S1Fout=zeros(1,steps);
% facultative species 2
S2Fout=zeros(1,steps);
%growth rate producers species 1
GPS1=zeros(1,steps);
%growth rate producers species 2
GPS2=zeros(1,steps);
%growth rate cheaters species 1 
GCS1=zeros(1,steps);
%growth rate cheaters species 2 
GCS2=zeros(1,steps);
%growth rate facultative species 2
GFS1=zeros(1,steps);
%growth rate facultative species 2
GFS2=zeros(1,steps);
% total population size species 1, normalized to carrying capacity K
PoptotNS1=zeros(1,steps);
% total population size species 2, normalized to carrying capacity K
PoptotNS2=zeros(1,steps);
% substance R1, net
R1net=zeros(1,steps);
% substance R2, net
R2net=zeros(1,steps);
% substance R1, per individual of species 1
R1bioavailable=zeros(1,steps);
%scaling factor between geologic and biologic time
dtgeodtbio=zeros(1,steps);
% substance R2, per individual of species 2
R2bioavailable=zeros(1,steps);
%abiotic influx R1
phiR1=zeros(1,steps);
%abiotic influx R2
phiR2=zeros(1,steps);
%total assimilation of substance R1 by species 1
TassimR1=zeros(1,steps);
%total assimilation of substance R2 by species 2
TassimR2=zeros(1,steps);
%total starvations before reproduction (deterministic thinning)
StarvationsS1=zeros(1,steps);
StarvationsS2=zeros(1,steps);
%phenotype switch, facultative genotype species 1, 1=producer, 0=cheater
SwitchfacS1=zeros(1,steps);
%phenotype switch, facultative genotype species 2, 1=producer, 0=cheater
SwitchfacS2=zeros(1,steps);
% residence time substance R1
RTR1=zeros(1,steps);
% residence time substance R2
RTR2=zeros(1,steps);
% biotic production of substance R1
BPR1=zeros(1,steps);
% biotic production of substance R2
BPR2=zeros(1,steps);
%cycling ratio R1
CRR1=zeros(1,steps);
%cycling ratio R2
CRR2=zeros(1,steps);
%off interval counter for fluctuation runs
offcounterrunning=zeros(1,steps);
%store of death probability for runs that change this 
deathprobrunning=zeros(1,steps);

% PREALLOCATE FIRST ELEMENT OF RELEVANT VECTORS FOR TIME ZERO
S1Pout(1)=S1P0;
S2Pout(1)=S2P0;
S1Cout(1)=S1C0;
S2Cout(1)=S2C0;
S1Fout(1)=S1F0;
S2Fout(1)=S2F0;
R1net(1)=R1net0;
R2net(1)=R2net0;
timeplot(1)=0;


% length of shutdown in substance input (single shut-off and fluctuation
% runs), generations
%offlength=100;
offlength=offlengthin;
offcounterrunning(1)=offlength;
%counter for shutdown
offcounterbase=offlength;
%fraction into run that perturbation of interest starts
perturbstartfrac=0.25;
%perturbstartfrac=0.5;
% for fluctuation runs, the fluctuations start at perturbfrac*steps and
% continue for an additional fluctuationfraction*steps
fluctuationfraction=0.5; % in addition to perturbstartfrac, cant exceed 1-perturbstartfrac

%TOGGLES FOR DIFFERENT KINDS OF RUN SETTINGS, 1=on 0=off
%single shutdown of substance input
singleofftoggle=1;
%singleofftoggle=0;
%sustained on-off substance input fluctuations
%fluctuationtoggle=1;
fluctuationtoggle=0;
% entrenchment (switch off mutation at entrenchmentfraction*steps into the
% run
%entrenchmenttoggle=1;
entrenchmenttoggle=0;
%entrenchment fraction for when it isn't combined with other things
% 0=whole run, 1=none of run
entrenchmentfraction0=0.5;

if entrenchmenttoggle==1
    %entrenchmentfraction=entrenchmentfraction0;
    entrenchmentfraction=entrenchin;

elseif entrenchmenttoggle==0
    entrenchmentfraction=1;
end;
        
%impose founder effects during the off interval and/or fluctuations, cut
%the population down to foundersize individuals per species
% for founder effects alone use the fluctuation setting without turning the
% influx off
%foundertoggle=1;
foundertoggle=0;
%foundersize=1;
foundersize=founderin;



for i=1:steps
    
    timeplot(i)=i*dt;
    %dtgeodtbio(i)=1;
    mutprobrunning(i)=mutprob0;
    
    %SINGLE SUBSTANCE SHUT-OFF
    if singleofftoggle==1
        if i<perturbstartfrac*steps
            dtgeodtbio(i)=1;
            if i>(perturbstartfrac-0.1)*steps
                deathprobrunning(i)=deathprobhigh;
                % artifical increase of mutation before shut-off
                %mutprobrunning(i)=0.5;
            else
                %mutprobrunning(i)=mutprob0;
                deathprobrunning(i)=deathprob0;
            end;
        else
            if i==perturbstartfrac*steps
                if foundertoggle==1 && ((S1Pout(i)+S1Cout(i)+S1Fout(i))>foundersize) ...
                            &&((S2Pout(i)+S2Cout(i)+S2Fout(i))>foundersize)
                        samplingvecS1=[];
                        samplingvecS2=[];
                        %sample labels:
                        % 0=p,1=C,2=F
                        samplingvecS1=[zeros(1,S1Pout(i)),ones(1,S1Cout(i)),...
                            2*ones(1,S1Fout(i))];
                        % without replacement
                        foundersample1=randsample(samplingvecS1,foundersize,false);
                        S1Pout(i)=sum(foundersample1(:)==0);
                        S1Cout(i)=sum(foundersample1(:)==1);
                        S1Fout(i)=sum(foundersample1(:)==2);
                        disp('bottlenecks check');
                        %disp(S1Pout(i)+S1Cout(i)+S1Fout(i));
                        samplingvecS2=[zeros(1,S2Pout(i)),ones(1,S2Cout(i)),2*ones(1,S2Fout(i))];
                        % without replacement
                        foundersample2=randsample(samplingvecS2,foundersize,false);
                        S2Pout(i)=sum(foundersample2(:)==0);
                        S2Cout(i)=sum(foundersample2(:)==1);
                        S2Fout(i)=sum(foundersample2(:)==2);
                        
                        if S1Pout(i)>0 && S2Pout(i)>0
                            disp('both producers survived the founder effect, time=');
                            disp(i*dt);
                        end;
                    end;
            end;
            if (i>=perturbstartfrac*steps) && i<(perturbstartfrac*steps+(offlength/dt))
                dtgeodtbio(i)=0;
                deathprobrunning(i)=deathprobhigh;
            else
                dtgeodtbio(i)=1;
                deathprobrunning(i)=deathprob0;
            end;
        end;
    else
        if fluctuationtoggle==0
            dtgeodtbio(i)=1;
            deathprobrunning(i)=deathprob0;
        end;
    end;
    
    %ON-OFF FLUCTUATIONS IN SUBSTANCE INPUT 
    if fluctuationtoggle==1
        if i<perturbstartfrac*steps || i>(perturbstartfrac+fluctuationfraction)*steps
            dtgeodtbio(i)=1;
            offcounterrunning(i)=offlength;
            deathprobrunning(i)=deathprob0;
            counter=0;
        else
            deathprobrunning(i)=deathprobhigh;
            if offcounterrunning(i-1)>0
                offcounterrunning(i)=max(0,offcounterrunning(i-1)-dt);
                dtgeodtbio(i)=dtgeodtbio(i-1);
            elseif offcounterrunning(i-1)==0
                if dtgeodtbio(i-1)>0
                    %COMMENT THIS LINE IN FOR FOUNDER EFFECTS WITHOUT
                    %FLUCTUATIONS
                    %dtgeodtbio(i)=1;
                    %ACTUAL FLUCUTATIONS:
                    dtgeodtbio(i)=0;
                else
                    dtgeodtbio(i)=1;
                end;
                offcounterrunning(i)=offlength;
                %new fluctuation on-off event starts, impose a founder
                %effect
                if foundertoggle==1 && ((S1Pout(i)+S1Cout(i)+S1Fout(i))>foundersize) ...
                        &&((S2Pout(i)+S2Cout(i)+S2Fout(i))>foundersize)
                    %disp('reset')
                    %disp(S1Pout(i)+S1Cout(i)+S1Fout(i));
                    samplingvecS1=[];
                    samplingvecS2=[];
                    % 0=p,1=C,2=F
                    samplingvecS1=[zeros(1,S1Pout(i)),ones(1,S1Cout(i)),2*ones(1,S1Fout(i))];
                    % without replacement
                    foundersample1=randsample(samplingvecS1,foundersize,false);
                    S1Pout(i)=sum(foundersample1(:)==0);
                    S1Cout(i)=sum(foundersample1(:)==1);
                    S1Fout(i)=sum(foundersample1(:)==2);
                    samplingvecS2=[zeros(1,S2Pout(i)),ones(1,S2Cout(i)),2*ones(1,S2Fout(i))];
                    % without replacement
                    foundersample2=randsample(samplingvecS2,foundersize,false);
                    S2Pout(i)=sum(foundersample2(:)==0);
                    S2Cout(i)=sum(foundersample2(:)==1);
                    S2Fout(i)=sum(foundersample2(:)==2);
                    if S1Pout(i)>0 && S2Pout(i)>0
                        counter=counter+1;
%                         disp('both producers survived the founder effect, time=');
%                         disp(i*dt);
                    end;
                end;
            end;
        end;
    end;
    
    
    
    
    %ENVIRONMENTAL SUBSTANCES, NET ABIOTIC INFLUX 
    phiR1(i)=R1influx*dtgeodtbio(i);
    phiR2(i)=R2influx*dtgeodtbio(i);    
    
    % CALCULATE BIOAVAILABLE SUBSTANCE, ASSUME SPATIAL HOMOGENEITY
    if (S1Pout(i)+S1Cout(i)+S1Fout(i))>0
        R1bioavailable(i)=max(0,R1net(i)/(S1Pout(i)+S1Cout(i)+S1Fout(i)));
    else
        R1bioavailable(i)=0;
    end;
    if (S2Pout(i)+S2Cout(i)+S2Fout(i))>0
        R2bioavailable(i)=max(0,R2net(i)/(S2Pout(i)+S2Cout(i)+S2Fout(i)));
    else
        R2bioavailable(i)=0;
    end;    
    
    %growth rates (offspring individuals per parent individual), baseline 
    % scalar in new individuals per unit substance assimilated per unit 
    %substance assimilated, multiplied by bioavailable substance, capped at a maximum)
    % producers
    GPS1(i)=min(S1GPPR*R1bioavailable(i)*fconv,S1GPmax);
    GPS2(i)=min(S2GPPR*R2bioavailable(i)*fconv,S2GPmax);
    
    PPS1(i)=min(GPS1(i)*fconvprod,S1GPmax*fconvprod);
    PPS2(i)=min(GPS2(i)*fconvprod*fsymmetry,S2GPmax*fconvprod);
    
    
    %cheaters
    GCS1(i)=min(S1GCPR*R1bioavailable(i)*fconv,S1GCmax);
    GCS2(i)=min(S2GCPR*R2bioavailable(i)*fconv,S2GCmax);

    % phenotypic switch for facultative genotype, producer=1
    %(store for graph)
    Rthres(i)=Rmin;
        if R1bioavailable(i)>Rmin
        SwitchfacS1(i)=1;
    else
        SwitchfacS1(i)=0;
    end;
    if R2bioavailable(i)>Rmin
        SwitchfacS2(i)=1;
    else
        SwitchfacS2(i)=0;
    end;
    % if bioavailable substance is below the threshold the facultative
    % genotype becomes a cheater, if above it is a producer
    if SwitchfacS1(i)==1
        GFS1(i)=GPS1(i);
    else
        GFS1(i)=GCS1(i);
    end;
    if SwitchfacS2(i)==1
        GFS2(i)=GPS2(i);
    else
        GFS2(i)=GCS2(i);
    end;
    
    %If the growth rates are <1 this implies the bioavailable substance
    %pool cannot sustain the existing population. If so impose the
    %corresponding number of starvations before the next round of
    %reproduction
    %producers
    StarvationsS1P(i)=round(S1Pout(i)*max(0,1-GPS1(i)));
    StarvationsS2P(i)=round(S2Pout(i)*max(0,1-GPS2(i)));
    %cheaters
    StarvationsS1C(i)=round(S1Cout(i)*max(0,1-GCS1(i)));
    StarvationsS2C(i)=round(S2Cout(i)*max(0,1-GCS2(i)));
    %facultative
    StarvationsS1F(i)=round(S1Fout(i)*max(0,1-GFS1(i)));
    StarvationsS2F(i)=round(S2Fout(i)*max(0,1-GFS2(i)));
    
    %adjust frequencies to those that survive to reproduction
    S1Pnet(i)=round(max(0,(S1Pout(i)-StarvationsS1P(i))));
    S2Pnet(i)=round(max(0,(S2Pout(i)-StarvationsS2P(i))));
    S1Cnet(i)=round(max(0,(S1Cout(i)-StarvationsS1C(i))));
    S2Cnet(i)=round(max(0,(S2Cout(i)-StarvationsS2C(i))));
    S1Fnet(i)=round(max(0,(S1Fout(i)-StarvationsS1F(i))));
    S2Fnet(i)=round(max(0,(S2Fout(i)-StarvationsS2F(i))));
    
    % CALCULATION OF NET ENVIRONMENTAL SUBSTANCE ASSIMILATION FLUXES
    % growth rate is in units of new individuals per parent individual.
    % Multiply by the number of parent individuals to get total new
    % individuals produced. Divide by genotype specific growth rate per
    % unit substance assimilated to get total, genotype specific
    % assimilation flux, 
    %i.e. units are individuals/(individuals/substance
    %assimiliated)=substance assimilated
    if GCS1(i)>0 & S1Cnet(i)>0
        AssimR1C(i)=S1Cnet(i)*GCS1(i)/S1GCPR;
    else
        AssimR1C(i)=0;
    end;
    if GPS1(i)>0 & S1Pnet(i)>0
        AssimR1P(i)=S1Pnet(i)*GPS1(i)/S1GPPR;
    else
        AssimR1P(i)=0;
    end;
    if GFS1(i)>0 & S1Fnet(i)>0
        if SwitchfacS1(i)==1
            AssimR1F(i)=S1Fnet(i)*GFS1(i)/S1GPPR;
        else
            AssimR1F(i)=S1Fnet(i)*GFS1(i)/S1GCPR;
        end;
    else
        AssimR1F(i)=0;
    end;
    if GCS2(i)>0 & S2Cnet(i)>0
        AssimR2C(i)=S2Cnet(i)*GCS2(i)/S2GCPR;
    else
        AssimR2C(i)=0;
    end;
    if GPS2(i)>0 & S2Pnet(i)>0
        AssimR2P(i)=S2Pnet(i)*GPS2(i)/S2GPPR;
    else
        AssimR2P(i)=0;
    end;
    if GFS2(i)>0 & S2Fnet(i)>0
        if SwitchfacS2(i)==1
            AssimR2F(i)=S2Fnet(i)*GFS2(i)/S2GPPR;
        else
            AssimR2F(i)=S2Fnet(i)*GFS2(i)/S2GCPR;
        end;
    else
        AssimR2F(i)=0;
    end;
    % total quantity of each environmental substance assimilated at this time-step  
    TassimR1(i)=max(0,AssimR1C(i)+AssimR1P(i)+AssimR1F(i));
    TassimR2(i)=max(0,AssimR2C(i)+AssimR2P(i)+AssimR2F(i));

    %BIOTIC PRODUCTION OF ENVIRONMENTAL SUBSTANCES
    %production fluxes in units of "out" resource produced per "in"
    %resource assimilated
    if GPS2(i)>0
        %BPR1(i)=S2Pout(i)*GPS2(i)*fconvprod/S2GPPR;
        BPR1(i)=max(0,S2Pout(i)*PPS2(i)/S2GPPR);
    else
        BPR1(i)=0;
    end;
    if GPS1(i)>0
        %BPR2(i)=S1Pout(i)*GPS1(i)*fconvprod/S1GPPR;
        BPR2(i)=max(0,S1Pout(i)*PPS1(i)/S1GPPR);
    else
        BPR2(i)=0;
    end;
    
    %RESIDENCE TIMES
    %amount of substance divided by influx of that substance from the
    %outside
    if phiR1(i)>0
        RTR1(i)=R1net(i)/phiR1(i);
    else
        RTR1(i)=0;
        if BPR1(i)>0
            RTR1(i)=R1net(i)/BPR1(i);
        else
            RTR1(i)=0;
        end;
    end;
    if phiR2(i)>0
        RTR2(i)=R2net(i)/phiR2(i);
    else
        RTR2(i)=0;
        if BPR2(i)>0
            RTR2(i)=R2net(i)/BPR2(i);
        else
            RTR2(i)=0;
        end;
    end;
    
    %CYCLING RATIOS
    % flux of substance through the biota (i.e. assimilation), divided 
    % by entry of substance into the biota from the outside
    if phiR1(i)>0 
        CRR1(i)=TassimR1(i)/phiR1(i);
    else
        if BPR1(i)>0 
            CRR1(i)=TassimR1(i)/BPR1(i);
        else
            if TassimR1(i)>0
                CRR1(i)=1;
            else
                CRR1(i)=0;
            end
        end;
    end;            
    if phiR2(i)>0
        CRR2(i)=TassimR2(i)/phiR2(i);
    else
        if BPR2(i)>0
            CRR2(i)=TassimR2(i)/BPR2(i);
        else
            if TassimR2(i)>0 
                CRR2(i)=1;
            else
                CRR2(i)=0;
        end;
    end;
    end;
    
    % CARRYING CAPACITY 
    %limitation by things other than environmental substance levels (i.e.
    %space etc), only really needed as a crash preventer for high growth
    %rates
    LimitationS1(i)=max(0,1-thinning*((S1Pout(i)+S1Cout(i)+S1Fout(i))/K));
    LimitationS2(i)=max(0,1-thinning*((S2Pout(i)+S2Cout(i)+S2Fout(i))/K));

    % calculate genotype specific per capita reproductive growth rates
    S1potentialP(i)=max(0,real(round(S1Pnet(i)*GPS1(i)*LimitationS1(i))));
    S2potentialP(i)=max(0,real(round(S2Pnet(i)*GPS2(i)*LimitationS2(i))));
    S1potentialC(i)=max(0,real(round(S1Cnet(i)*GCS1(i)*LimitationS1(i))));
    S2potentialC(i)=max(0,real(round(S2Cnet(i)*GCS2(i)*LimitationS2(i))));
    S1potentialF(i)=max(0,real(round(S1Fnet(i)*GFS1(i)*LimitationS1(i))));
    S2potentialF(i)=max(0,real(round(S2Fnet(i)*GFS2(i)*LimitationS2(i))));
    
    % TURN ON ENTRENCHMENT IN THE RELEVANT RUNS
    %if i<=entrenchmentfraction*steps
    %if (S1Pout(i)+S1Cout(i)+S1Fout(i))>0
    if i>=entrenchmentfraction*steps
        if (S1Pout(i)+S1Cout(i)+S1Fout(i))>0
            %disp('mutation off, things still alive');
        end;
        S1potentialmutantsfromP(i)=0;
        S2potentialmutantsfromP(i)=0;
        S1potentialmutantsfromC(i)=0;
        S2potentialmutantsfromC(i)=0;
        S1potentialmutantsfromF(i)=0;
        S2potentialmutantsfromF(i)=0;
         
 
    else
        %BASELINE CALCULATION OF MUTATION
        %disp(S1potentialP(i));
       
        S1potentialmutantsfromP(i)=binornd(S1potentialP(i),mutprobrunning(i));
        S2potentialmutantsfromP(i)=binornd(S2potentialP(i),mutprobrunning(i));
        S1potentialmutantsfromC(i)=binornd(S1potentialC(i),mutprobrunning(i));
        S2potentialmutantsfromC(i)=binornd(S2potentialC(i),mutprobrunning(i));
        S1potentialmutantsfromF(i)=binornd(S1potentialF(i),mutprobrunning(i));
        S2potentialmutantsfromF(i)=binornd(S2potentialF(i),mutprobrunning(i));
        

        
    end;
    
    % number of wild type offspring
    S1potentialwildtypeP(i)=S1potentialP(i)-S1potentialmutantsfromP(i);
    S2potentialwildtypeP(i)=S2potentialP(i)-S2potentialmutantsfromP(i);
    S1potentialwildtypeC(i)=S1potentialC(i)-S1potentialmutantsfromC(i);
    S2potentialwildtypeC(i)=S2potentialC(i)-S2potentialmutantsfromC(i); 
    S1potentialwildtypeF(i)=S1potentialF(i)-S1potentialmutantsfromF(i);
    S2potentialwildtypeF(i)=S2potentialF(i)-S2potentialmutantsfromF(i);
    
    %species 1, allocate mutants to the other genotypes
    S1counterPtoC=0;
    S1counterPtoF=0;
    for m=1:S1potentialmutantsfromP(i)
        x=rand();
        if x>0.5
            S1counterPtoC=S1counterPtoC+1;
        else
            S1counterPtoF=S1counterPtoF+1;
        end
    end;
    
    S1counterCtoP=0;
    S1counterCtoF=0;
    for m=1:S1potentialmutantsfromC(i)
        x=rand();
        if x>0.5
            S1counterCtoP=S1counterCtoP+1;
        else
            S1counterCtoF=S1counterCtoF+1;
        end
    end;
    
    S1counterFtoP=0;
    S1counterFtoC=0;
    for m=1:S1potentialmutantsfromF(i)
        x=rand();
        if x>0.5
            S1counterFtoP=S1counterFtoP+1;
        else
            S1counterFtoC=S1counterFtoC+1;
        end
    end;
    
    S1potentialmutantstoP(i)=S1counterCtoP+S1counterFtoP;
    S1potentialmutantstoC(i)=S1counterPtoC+S1counterFtoC;
    S1potentialmutantstoF(i)=S1counterCtoF+S1counterPtoF;
    
    if (S1potentialmutantsfromP(i)+S1potentialmutantsfromC(i)+S1potentialmutantsfromF(i))...
            ~=(S1potentialmutantstoP(i)+S1potentialmutantstoC(i)+...
            S1potentialmutantstoF(i))
         disp('warning, species 1 mutation allocation mismatch');
         disp('from')
         disp(S1potentialmutantsfromP(i))
         disp(S1potentialmutantsfromC(i))
         disp(S1potentialmutantsfromF(i))
         disp('to')
         disp(S1potentialmutantstoP(i)+S1potentialmutantstoC(i)+S1potentialmutantstoF(i))
    end;
    
    %species 2, allocate mutants to the other genotypes
    S2counterPtoC=0;
    S2counterPtoF=0;
    for m=1:S2potentialmutantsfromP(i)
        x=rand();
        if x>0.5
            S2counterPtoC=S2counterPtoC+1;
        else
            S2counterPtoF=S2counterPtoF+1;
        end
    end;
    
    S2counterCtoP=0;
    S2counterCtoF=0;
    for m=1:S2potentialmutantsfromC(i)
        x=rand();
        if x>0.5
            S2counterCtoP=S2counterCtoP+1;
        else
            S2counterCtoF=S2counterCtoF+1;
        end
    end;
    
    S2counterFtoP=0;
    S2counterFtoC=0;
    for m=1:S2potentialmutantsfromF(i)
        x=rand();
        if x>0.5
            S2counterFtoP=S2counterFtoP+1;
        else
            S2counterFtoC=S2counterFtoC+1;
        end
    end;
    
    S2potentialmutantstoP(i)=S2counterCtoP+S2counterFtoP;
    S2potentialmutantstoC(i)=S2counterPtoC+S2counterFtoC;
    S2potentialmutantstoF(i)=S2counterCtoF+S2counterPtoF;
    if (S2potentialmutantsfromP(i)+S2potentialmutantsfromC(i)+S2potentialmutantsfromF(i))...
            ~=(S2potentialmutantstoP(i)+S2potentialmutantstoC(i)+...
            S2potentialmutantstoF(i))
        disp('warning, species 2 mutation allocation mismatch');
    end;
    
    
    % deaths due to factors other than starvation (stochastic)
    S1Pdeaths(i)=binornd(round(S1Pout(i)),deathprobrunning(i));
    S2Pdeaths(i)=binornd(round(S2Pout(i)),deathprobrunning(i));
    S1Cdeaths(i)=binornd(round(S1Cout(i)),deathprobrunning(i));
    S2Cdeaths(i)=binornd(round(S2Cout(i)),deathprobrunning(i));
    S1Fdeaths(i)=binornd(round(S1Fout(i)),deathprobrunning(i));
    S2Fdeaths(i)=binornd(round(S2Fout(i)),deathprobrunning(i));
    
    % DERIVATIVES
    % plug into derivatives to calculate frequencies for subsequent
    % timestep (euler maruyama)
    if i<steps
        S1Pout(i+1)=round(max(0,S1Pout(i)...
            +S1potentialP(i)*dt...
        -S1potentialmutantsfromP(i)*sqrt(dt)...
            +S1potentialmutantstoP(i)*sqrt(dt)-S1Pdeaths(i)*sqrt(dt)));
        if(isnan(S1Pout(i+1))==1)
            S1Pout(i+1)=0;
        end;
        
        S2Pout(i+1)=round(max(0,S2Pout(i)...
            +S2potentialP(i)*dt...
        -S2potentialmutantsfromP(i)*sqrt(dt)...
            +S2potentialmutantstoP(i)*sqrt(dt)-S2Pdeaths(i)*sqrt(dt)));
        if(isnan(S2Pout(i+1))==1)
            S2Pout(i+1)=0;
        end;

        S1Cout(i+1)=round(max(0,S1Cout(i)...
            +S1potentialC(i)*dt...
        -S1potentialmutantsfromC(i)*sqrt(dt)...
            +S1potentialmutantstoC(i)*sqrt(dt)-S1Cdeaths(i)*sqrt(dt)));
        if(isnan(S1Cout(i+1))==1)
            S1Cout(i+1)=0;
        end;
        
        S2Cout(i+1)=round(max(0,S2Cout(i)...
            +S2potentialC(i)*dt...
        -S2potentialmutantsfromC(i)*sqrt(dt)...
            +S2potentialmutantstoC(i)*sqrt(dt)-S2Cdeaths(i)*sqrt(dt)));
        if(isnan(S2Cout(i+1))==1)
            S2Cout(i+1)=0;
        end;

        S1Fout(i+1)=round(max(0,S1Fout(i)...
            +S1potentialF(i)*dt...
        -S1potentialmutantsfromF(i)*sqrt(dt)...
            +S1potentialmutantstoF(i)*sqrt(dt)-S1Fdeaths(i)*sqrt(dt)));
        if(isnan(S1Fout(i+1))==1)
            S1Fout(i+1)=0;
        end;
        
        S2Fout(i+1)=round(max(0,S2Fout(i)...
            +S2potentialF(i)*dt...
        -S2potentialmutantsfromF(i)*sqrt(dt)...
            +S2potentialmutantstoF(i)*sqrt(dt)-S2Fdeaths(i)*sqrt(dt)));
        if(isnan(S2Fout(i+1))==1)
            S2Fout(i+1)=0;
        end;
        
        %environmental substance derivatives
        R1net(i+1)=max(0,R1net(i)+BPR1(i)-TassimR1(i)+phiR1(i)-(R1net(i)/R1net0));
        if(isnan(R1net(i+1))==1)
            R1net(i+1)=0;
        end;
        R2net(i+1)=max(0,R2net(i)+BPR2(i)-TassimR2(i)+phiR2(i)-(R2net(i)/R2net0));
        if(isnan(R2net(i+1))==1)
            R2net(i+1)=0;
        end;
    end;
    end;
            
    CRR1final=CRR1(steps);
    CRR2final=CRR2(steps);
    if CRR2final>0 && CRR2final>0
        CRmean=(CRR1(steps)+CRR2(steps))*0.5;
    else
        CRmean=0;
    end;
    
    if (CRR1final>0 && CRR2final==0) | (CRR2final>0 && CRR1final==0)
        CRasym=1;
    else
        CRasym=0;
    end;
    
    
    
    if isnan(CRmean)==1
        CRmean=0;
    end;
    RFP1final=S1Pout(steps)/(S1Pout(steps)+S1Cout(steps)+S1Fout(steps));
    if isnan(RFP1final)==1
        RFP1final=0;
    end;
    RFP2final=S2Pout(steps)/(S2Pout(steps)+S2Cout(steps)+S2Fout(steps));
    if isnan(RFP2final)==1
        RFP2final=0;
    end;
    if RFP1final>0 && RFP2final>0
        Prodmean=(RFP1final+RFP2final)/2;
    else
        Prodmean=0;
    end;
    

    if isnan(Prodmean)==1
        Prodmean=0;
    end;
    
    S1final=S1Pout(steps)+S1Cout(steps)+S1Fout(steps);
    S2final=S2Pout(steps)+S2Cout(steps)+S2Fout(steps);
    
    if (S1final>0 && S2final==0) | (S2final>0 && S1final==0)
        Popasym=1;
    else
        Popasym=0;
    end;
    
    
    if S1final>1 && S2final>1
        Popmean=(S1final+S2final)/2;
    else
        Popmean=0;
    end;
    Assimmean=(TassimR1(steps)+TassimR1(steps))/2;

    if graphtoggle==1 
%if Popmean<0
      %figure;
      figure;  
      subplot(4,2,1);

      plot(timeplot,S1Pout,'b',timeplot,S2Pout,'b--',timeplot,S1Cout,'r'...
          ,timeplot,S2Cout,'r--',timeplot,S1Fout,'g',timeplot,S2Fout,'g--','linewidth',3.0);
        ylabel('individuals');
        xlabel('generations');
        legend('producer S_1','producer S_2','non-producer S_1','non-producer S_2',...
            'plastic S_1','plastic S_2','location','southoutside','NumColumns',3);
        xlim([0 gens]);
        
        %title({'cost='+string(costin),'1: Species frequencies'});
        title({'shut-off='+string(offlengthin),' mut='+string(mutin),' cost='+string(costin)});
            %'1: Species frequencies'});


        subplot(4,2,3);
        plot(timeplot,phiR1,'color',[0.4940 0.1840 0.5560],'linewidth',3.0)
        hold on
        plot(timeplot,phiR2,'linestyle','--','color',[0.4940 0.1840 0.5560],'linewidth',3.0)
        hold on
        plot(timeplot,TassimR1,'color',[0.6350 0.0780 0.1840],'linewidth',3.0)
        hold on
        plot(timeplot,TassimR2,'linestyle','--','color',[0.6350 0.0780 0.1840],'linewidth',3.0)
        hold on
        plot(timeplot,BPR1,'color',[0.3010 0.7450 0.9330],'linewidth',3.0)
        hold on
        plot(timeplot,BPR2,'linestyle','--','color',[0.3010 0.7450 0.9330],'linewidth',3.0)
        
        legend('R_1 abiotic influx','R_2 abiotic influx','R_1 biotic\newlineassimilation',...
            'R_2 biotic\newlineassimilation','Biological production\newlineof R_1 by S_2',...
            'Biological production\newlineof R_2 by S_2','location','southoutside');
        xlim([0 gens]);
        ylabel('R_1 units per generation');
        xlabel('generations');
        title('2.Fluxes');

        subplot(4,2,5);
        plot(timeplot,CRR1,'color',[1 0 1],'linewidth',3.0);
        hold on
        plot(timeplot,CRR1,'linestyle','--','color',[0.7 0 0.7],'linewidth',3.0);
        ylabel('R_1 assimilation/influx');
        legend('cycling ratio R_1','cycling ratio R_2','location','southoutside');
        xlim([0 gens]);
        title('3: Cycling ratios');
        xlabel('generations');
        subplot(4,2,7)
    %     subplot(3,2,6);
    %     %subplot(4,2,6);
        plot(timeplot,R1net,'color',[0.9290 0.6940 0.1250],'linewidth',3.0);
        hold on
        plot(timeplot,R1net,'linestyle','--','color',[0.8 0.5 0.02],'linewidth',3.0);
        xlim([0 gens]);
        legend('R_1 (net)','R_2 (net)','location','southoutside');
        xlabel('generations');
        ylabel('R_1 units');
        title('4: Environmental substance level');
    %     
        %close(f1);
end;
    
end






